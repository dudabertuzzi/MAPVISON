// LoginActivity.kt
package com.example.mapvision

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.CheckBox

class LoginActivity : AppCompatActivity() {

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val btnRegister = findViewById<TextView>(R.id.etEmail)
        val btnForgotPassword = findViewById<TextView>(R.id.etPassword)
        val btnLogin = findViewById<Button>(R.id.btn_login)

        // Navega para a tela de redefinição de senha
        btnForgotPassword.setOnClickListener {
            val intent = Intent(this, ForgotPasswordActivity::class.java)
            startActivity(intent)
        }

        // Navega para a tela de cadastro (placeholder)
        btnRegister.setOnClickListener {
            // Lógica para abrir a tela de cadastro
        }

        // Login Simples (apenas exemplo)
        btnLogin.setOnClickListener {
            // Verificação de login aqui (placeholder)
        }
    }
}
